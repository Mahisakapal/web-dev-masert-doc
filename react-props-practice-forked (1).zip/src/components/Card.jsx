import React from "react";

function Card(porps) {
  return (
    <div className="card">
      <div className="top">
        <h2 className="name">{porps.name}</h2>
        <img className="circle-img" src={porps.img} alt="avatar_img" />
      </div>
      <div className="bottom">
        <p className="info">{porps.tel}</p>
        <p className="info">{porps.email}</p>
      </div>
    </div>
  );
}

export default Card;
