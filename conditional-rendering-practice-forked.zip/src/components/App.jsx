import React from "react";
import Form from "./Form";

var userIsRegistered = false; // if you chnage the value it chnage componet

function App() {
  return (
    <div className="container">
      <Form IsRegistered={userIsRegistered} />
    </div>
  );
}

export default App;
