import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";

ReactDOM.render(<App />, document.getElementById("root"));

//CHALLENGE: Make the code in App.jsx work.
//The final app should have a single contact
//with fName, lName and email.
