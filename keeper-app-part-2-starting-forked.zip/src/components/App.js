import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import notes from "../notes.js";

function App() {
  return (
    <div>
      <Header />
      {notes.map((any_name) => (
        <Note
          key={any_name.id} // one filed should be unique
          title={any_name.title}
          content={any_name.content}
        />
      ))}

      <Footer />
    </div>
  );
}

export default App;
